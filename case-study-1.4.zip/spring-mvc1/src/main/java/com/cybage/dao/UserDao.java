package com.cybage.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.cybage.controller.Users;
import com.cybage.exception.UserException;

@Repository
public class UserDao {
	private List<Users> users = new ArrayList<Users>();
	{
		users.add(new Users(101, "dm101"));
		users.add(new Users(102, "dm102"));
		users.add(new Users(103, "dm103"));
		users.add(new Users(104, "dm104"));
		users.add(new Users(105, "dm105"));		
	}
	public List<Users> getUsers() throws UserException{
		if(users.size() == 0) throw new UserException("No user exists...");
		return users;
	}
	public void deleteById(int id) throws UserException{
		boolean remove = users.removeIf(u -> u.getId() == id);
		if(remove == false) throw new UserException("no user found");
	}
	public Optional<Users> findById(int id) {
		return users
		.stream()
		.filter(u -> u.getId() == id)
		.findFirst();		
	}
	public void updateUser(Users user) {
		users.removeIf(u -> u.getId() == user.getId());
		users.add(user);
	}
	public void addUser(Users user) {
		users.add(user);
	}		
}
