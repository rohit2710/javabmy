package com.cybage.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")			// localhost:8080/admin
public class AdminController {
	@RequestMapping("/home")		// localhost:8080/admin/home
	public String admin() {
		return "admin";
	}
}