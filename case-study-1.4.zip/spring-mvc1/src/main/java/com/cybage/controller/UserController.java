package com.cybage.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.dao.UserDao;
import com.cybage.exception.UserException;

@Controller
public class UserController {
	
	@Autowired 
	UserDao userDao;
	
	@RequestMapping("/home")
	public String user() {
		return "user";
	}
	
	@GetMapping("/user")
	public ModelAndView getUsers() throws UserException{
		ModelAndView mv = new ModelAndView("user");
		mv.addObject("users", userDao.getUsers());		
		return mv;
	}
	
	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	public String deleteUser(@PathVariable int id) throws UserException{
		userDao.deleteById(id);
		return "redirect:/user";
	} 
	@RequestMapping(value = "/edituser/{id}", method = RequestMethod.GET)
	public String editUser(@PathVariable int id, Model model) {
		model.addAttribute("user", userDao.findById(id));
		return "edituser";
	} 
	@RequestMapping(value = "/updateuser", method = RequestMethod.POST)
	public String editUser(@ModelAttribute("user") Users user) {
		//logic for updation
		userDao.updateUser(user);		
		return "redirect:/user";
	} 
	@RequestMapping(value = "/showuserform", method = RequestMethod.GET)
	public String showUserForm(Model model) {
		model.addAttribute("user", new Users());
		return "userform";
	} 
	@RequestMapping(value = "/adduser", method = RequestMethod.POST)
	public String addUser(@Valid @ModelAttribute("user") Users user, BindingResult result) {
		//logic for adding user
		if(result.hasErrors()) {
			return "userform";
		}
		userDao.addUser(user);		
		return "redirect:/user";
		
	} 
}