package com.cybage.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.exception.UserException;

@ControllerAdvice		//capable to handle exception within application
public class ExceptionController {
	private static final Logger logger = LoggerFactory.getLogger(ExceptionController.class);
	
	@ExceptionHandler(UserException.class)
	public ModelAndView handleUserException(UserException ue) {
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("message", ue.getMessage());
		logger.error("exception in processing request: " + ue.getMessage());
		return mv;
	}
	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception e) {
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("message", e.getMessage());
		logger.error("exception in processing request: " + e.getMessage());
		return mv;
	}
}
