function fun1() {
    var arr = [1,2,3,4,5]
    console.log('print array: '+arr)

    var arr = new Array(1,2,3,4,5)
    console.log('print array: '+arr)

    //access and update using 0 based index

     //array are object
     console.log('typeof array: ' + typeof arr)

     //properties
     console.log('length: '+ arr.length)

     //looping array, using for loop

     //loop using foreach method
     console.log('using foreach method')
     arr.forEach( 
         function(x){
             console.log(x)
         }
     )

     //adding element
     arr.push(10)
     console.log('print array: '+arr)

     //convert to string
     var arrStr = arr.toString()
     console.log('typeof arrStr: ' + typeof arrStr)

     //pop() remove last element
     arr.pop();
     console.log('print array: '+arr)

     //shift() remove first element
     arr.shift();
     console.log('print array: '+arr)

     //unshift() remove last element
     arr.unshift(123);
     console.log('print array: '+arr)

     //delete element
     delete arr[2]
     console.log('print array: '+arr)
    
    //splicing array
    var arr = [1,2,3,4,5]
    arr.splice(2, 0, 1234, 765)
    //2 --> position, 0--> how many element to be removed, rest element will be added on given position
    console.log('print array: '+arr)

    //slicing array
    var arr = [1,2,3,4,5]
    var sl = arr.slice(2, 4);
    console.log('sliced array: '+ sl)

    //sorting
    var arr = ['one', 'two', 'three']
    arr.sort();
    console.log('sorted array: '+ arr)
    arr.reverse()
    console.log('reverse sorted array: '+ arr)

    //for number sorting pass function
    var arr = [1,2,3,4,5]
    arr.sort(function(a,b){ return a-b})
    console.log(arr)

    //reverse sorting
    var arr = [1,2,3,4,5]
    arr.sort(function(a,b){ return b-a})
    console.log(arr)
    mx = Math.max.apply(null, arr)
    console.log('max: ' + mx )

    //array filtering
    var above3 = arr.filter(function (x) { return x>3})
    console.log('elements > 3 : ' + above3)

    //reduce
    var sum = arr.reduce(function(t, v){ return t+v})
    console.log('sum is: '+ sum)

    //indexof, lastindexof

     
 }