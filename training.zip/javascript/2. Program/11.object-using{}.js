//create object
function fun1() {
    //1. create object using {}
    var emp = { name: 'dmjadhav', address: 'pune' }
    console.log(emp)
    //add more properties
    emp.email = 'dm@gmail.com'
    console.log(emp)
    //add more functions
    emp.print = function () { console.log('Name: ' + this.name + '  address: ' + this.address + '  email: ' + this.email) }
    emp.print()
}