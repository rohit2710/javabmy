
function fun1() {

    function Human(first, last, age) {
        this.firstName = first;
        this.lastName = last;
    }
    var p1 = new Human('dm', 'jadhav')
    var p2 = new Human('dm1', 'jadhav1')
    console.log(p1)
    console.log(p2)

    //adding property / method to object
    p1.age = 35
    console.log(p1.age)
    console.log(p2.age)             //undefined as property added to p1 object only 
    
    //print prototype of human
    console.log(Human.prototype)

    //check for same prototype
    console.log(Human.prototype === p1.__proto__)
    console.log(Human.prototype === p2.__proto__)
    console.log(p1.__proto__ === p2.__proto__)    

    //add new property
    console.log('adding new property')
    Human.prototype.email = 'dm@gmail.com'    
    //both object will get same value
    console.log(p1.email)               //fetch value from Human constructor
    console.log(p2.email)

    //modify value for newly added property
    console.log('modification to property')
    p1.email = 'newemail@gmail.com'
    console.log(p1.email)                   
    console.log(p2.email)

    //adding property to Object.prototype
    console.log('adding property to Object.prototype')
    Object.prototype.orgName = 'cybage'
    console.log(p1.orgName)                //fetch value from Object.prototype
    console.log(p2.orgName)

    //adding shared function
    console.log('combining constructor and prototype')
    Human.prototype.greet = function (){
        console.log('Hello : ' + this.firstName)
    }
    p1.greet()
    p2.greet()    
}
fun1()