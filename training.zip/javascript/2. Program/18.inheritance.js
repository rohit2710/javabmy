var human = { firstName: 'dm', lastName: 'jadhav', };
var emp = { salary: 123 }
emp.__proto__ = human
console.log('print employee information')
console.log(emp.firstName)
console.log(emp.lastName)
console.log(emp.salary)
