//create object
function fun1() {
    //1. create object using {}
    var emp = {
        name: 'dmjadhav',
        address: 'pune',
        get details() {
            return 'name: '+ this.name + ' address: '+ this.address;
        },
        set changeName(name){
            this.name = name;
        }
    }
}