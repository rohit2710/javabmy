function fun1() {
      'use strict';
    a = 'dmjadhav'
    console.log(a)
    // delete a;
    console.log(a)
    var undefined = 5;
    console.log(undefined)

    var Infinity = 234;
    console.log(Infinity)            
}

function fun2(){
    a = 'dm'
    console.log(a)
    var a
     
    console.log(window)
}

 