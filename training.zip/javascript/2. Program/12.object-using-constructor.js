//create object
function fun1() {
    //3. using constructor
    function Person(first, last, age, eye) {
        this.firstName = first;
        this.lastName = last;
        this.age = age;
        this.eyeColor = eye;
    }
    var p1 = new Person('dm', 'jadhav', 35, 'black')
    var p2 = new Person('dm1', 'jadhav1', 36, 'blue')
    console.log(p1)
    console.log(p2)
}