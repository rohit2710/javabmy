function fun1() {
  'use strict';

  var Person = {
    name: { fname: "dm", lname: "jadhav" },
    age: 35
  }
  Object.defineProperty(Person, 'name', { enumerable: false });

  for (var p in Person)
    console.log(p + " : " + Person[p])
}
 