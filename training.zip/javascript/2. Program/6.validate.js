function validateForm() {
  var ip = document.getElementsByName('fname')[0].value;

  var nameExp = /^[a-zA-Z]+$/;
  var numExp = /^[0-9]+$/;
  








  
  var phone = document.getElementsByName('phone')[0].value;
  var phoneExp = /^[(][0-9]{3}[)][-][0-9]{3}[-][0-9]{4}$/
  //   (123)-543-7654

  if(phone.match(phoneExp)){
    return true;
  }else{
    alert('phone number not valid')
    phone.focus();
    return false
  }
}