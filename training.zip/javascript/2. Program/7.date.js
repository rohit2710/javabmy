function fun1() {
    var dt = new Date()
    console.log('current date: '+ dt)

    var dt = new Date('October 15, 2019')
    console.log('custom date: '+ dt)
    console.log('date: '+ dt.getDate())
    console.log('Month: '+ dt.getMonth())
    console.log('Seconds: '+ dt.getSeconds())
    console.log('Year: '+ dt.getFullYear())
    console.log('Time: '+ dt.getTime())    
}