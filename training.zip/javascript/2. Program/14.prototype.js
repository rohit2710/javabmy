
function fun1() {
    //using constructor
    function Person(first, last, age, eye) {
        this.firstName = first;
        this.lastName = last;
        this.age = age;
        this.eyeColor = eye;
    }
    var p1 = new Person('dm', 'jadhav', 35, 'black')
    var p2 = new Person('dm1', 'jadhav1', 36, 'blue')
    console.log(p1)
    console.log(p2)

    Person.prototype.nationality = "indian";

    Person.prototype.print = function(){
        console.log('first Name: '+ this.firstName)
        console.log('Last name: '+ this.lastName)
        console.log('Age: '+ this.age)
        console.log('Eye color: '+ this.eyeColor)
        console.log('Nationality: '+ this.nationality)
    }
    p1.print()
    p2.print()
}