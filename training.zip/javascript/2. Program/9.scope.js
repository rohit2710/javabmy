//global variables
var orgName = 'cybage, Pune'
function fun1(){
    //local variable
    var name = 'Dadaram Jadhav'
    console.log('Name: '+ name + '   Organization name: '+ orgName)
}