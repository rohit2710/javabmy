//reference object
function Customer(first, last, status) { 
    this.first = first;
    this.last = last;
    this.status = status;
 
    this.say = function () {
        alert("name: " + this.first + " " + this.last +
              ", status: " + this.status);
    };
}

//it will return prototype or copy of object
function CustomerPrototype(proto) {     //proto --> existing object
    this.proto = proto;

    this.clone = function () {
        var customer = new Customer();  //clone 
        //copy every value from existing object to new object
        customer.first = proto.first;        
        customer.last = proto.last;
        customer.status = proto.status;
        //return exact copy to client
        return customer;
    };
}
  
function run() { 
    var proto = new Customer("na", "na", "pending");   //reference object

    var prototype = new CustomerPrototype(proto);
    //new created object
 
    var customer = prototype.clone();
    customer.say();
}