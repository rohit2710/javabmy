var FullTime = function () {
    this.hourly = "123";
};
 
var PartTime = function () {
    this.hourly = "343";
};
 
var Temporary = function () {
    this.hourly = "876";
};
 
var Contractor = function () {
    this.hourly = "567";
};

function Factory() {
    this.createEmployee = function (type) {
        var employee;
 
        if (type === "fulltime") {
            employee = new FullTime();
        } else if (type === "parttime") {
            employee = new PartTime();
        } else if (type === "temporary") {
            employee = new Temporary();
        } else if (type === "contractor") {
            employee = new Contractor();
        }
 
        employee.type = type;
 
        employee.print = function () {
            console.log(this.type + ": rate " + this.hourly + "/hour");
        } 
        return employee;
    }
}
 
//client
function run() {
    var employees = [];     //in four employee
    var factory = new Factory();
    employees.push(factory.createEmployee("fulltime"));
    employees.push(factory.createEmployee("parttime"));
    employees.push(factory.createEmployee("temporary"));
    employees.push(factory.createEmployee("contractor"));
    
    for (var i = 0, len = employees.length; i < len; i++) {
        employees[i].print();
    }  
}