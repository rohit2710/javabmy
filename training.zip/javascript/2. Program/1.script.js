function fun1() {
    console.log('button clicked...');
    try{
        throw new Error('error occurred')
    }catch(er){
         
        console.log(er.message)
    }
}