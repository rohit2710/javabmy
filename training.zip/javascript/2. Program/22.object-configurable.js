function fun1() {
    'use strict';
    var Cat = {
        name: "Fulffy",
        color: "White"
    };
    // Object.defineProperty(Cat, 'name', { configurable: false });
    Object.defineProperty(Cat, 'name', { enumerable: false });//we cant do
    // Object.defineProperty(Cat, 'name', { configurable: true });//we cant do
    // Object.defineProperty(Cat, 'name', { writable: false });//we can do

    for(var p in Cat){
        console.log(Cat[p])
    }

}
fun1();