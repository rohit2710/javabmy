const { Observable } = require('rxjs');

var obs = new Observable( ob =>{
    ob.next(10)
    ob.next(20)
})

obs.subscribe( x=>{
    console.log(x)
})