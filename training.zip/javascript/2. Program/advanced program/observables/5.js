const { of } = require('rxjs')
const { reduce } = require('rxjs/operators');

// create an observable out of list of integers
const myObservable = of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

// define accumulator function for reduce
const factorialAccumulatorFunction = 
    (accumulated, current) => (accumulated * current);

// multiply over time, starting with 1; reduce
myObservable
.pipe(reduce(factorialAccumulatorFunction, 1))
.subscribe(val => console.log(val));