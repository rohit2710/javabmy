const { Observable } = require('rxjs');

function f1(){
    return new Observable( ob=>{
        ob.next(20)
    })
}

f1().subscribe(x => console.log(x))