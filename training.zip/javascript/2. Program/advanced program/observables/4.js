const { of } = require('rxjs')
const { scan } = require('rxjs/operators');

// create an observable out of list of integers
const myObservable = of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

// define accumulator function for scan
const factorialAccumulatorFunction = 
    (accumulated, current) => (accumulated * current);

// multiply over time, starting with 1
myObservable
.pipe(scan(factorialAccumulatorFunction, 1))
.subscribe(val => console.log(val));