const _ = require("lodash")

const ver = _.VERSION
console.log(ver);    