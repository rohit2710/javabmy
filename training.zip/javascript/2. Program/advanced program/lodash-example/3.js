const _ = require("lodash")
console.log("Getting array slice")
let nums2 = [1, 2, 3, 4, 5, 6, 7, 8, 9];

let c1 = _.slice(nums2, 2, 6);
console.log(c1);

let c2 = _.slice(nums2, 0, 8);
console.log(c2);

console.log("Lodash random number")
let r = _.random(10);
console.log(r);

r = _.random(5, 10);
console.log(r);

console.log("Lodash random array element")
let words = ['sky', 'wood', 'forest', 'falcon', 
    'pear', 'ocean', 'universe'];

let word = _.sample(words);
console.log(word);

console.log("Lodash shuffling array elements")
let wd = ['sky', 'wood', 'forest', 'falcon', 
    'pear', 'ocean', 'universe'];

console.log(_.shuffle(wd));
console.log(_.shuffle(wd));
console.log(_.shuffle(wd));
console.log(wd);


console.log("Lodash _.delay function")
function message()
{
    console.log("Some message");
}

_.delay(message, 150);
console.log("Some other message");