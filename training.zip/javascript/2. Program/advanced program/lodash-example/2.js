console.log("Lodash first and last array elements")
const _ = require("lodash")

let words = ['sky', 'wood', 'forest', 'falcon', 
    'pear', 'ocean', 'universe'];

let fel = _.first(words);
let lel = _.last(words);

console.log(`First element: ${fel}`);
console.log(`Last element: ${lel}`);

console.log("Lodash nth array elements")
let nums = [1, 2, 3, 4, 5, 6, 7, 8];
 
console.log(_.nth(nums, 3));
console.log(_.nth(nums, -3));

console.log("Lodash chunking array")
let nums1 = [1, 2, 3, 4, 5, 6, 7, 8, 9];

let c1 = _.chunk(nums1, 2);
console.log(c1);

let c2 = _.chunk(nums1, 3);
console.log(c2);

