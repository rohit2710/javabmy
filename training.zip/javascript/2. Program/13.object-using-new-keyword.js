//create object
function fun1() {
     
    //2. create object using new keyword
    var person = new Object();
    person.firstName = "dm";
    person.lastName = "jadhav";
    person.age = 35;

    console.log(person)
    //access property using alternative syntax
    console.log('Name: ' + person['firstName'])

    //use of for..in loop
    for (i in person) {
        console.log(person[i])
    }

    //delete property
    delete person.age
    console.log(person)
}
fun1()