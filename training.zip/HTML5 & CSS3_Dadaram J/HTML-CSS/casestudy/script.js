function fun1(){
    //we trying to show or hide nav bar on click of toggle image
    let navbar = document.querySelector('.nav-bar')
    if(navbar.style.display === 'flex'){
        navbar.style.display = 'none'
    }else{
        navbar.style.display = 'flex'
    }
}