package com.cybage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cybage.entity.EnrollmentStatus;
import com.cybage.entity.Enrollments;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollments, Integer> {

      public List<Enrollments> findByEnrollmentStatus(EnrollmentStatus status);

	
}
