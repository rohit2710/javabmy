package com.cybage.entity;

public enum Roles {
	MEMBER,ADMIN,MANAGER
}
