package com.cybage.entity;

public enum EnrollmentStatus {
	PENDING,APPROVED,REJECTED
}
