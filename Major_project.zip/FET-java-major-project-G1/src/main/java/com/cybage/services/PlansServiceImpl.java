package com.cybage.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cybage.dto.PlansDto;

import com.cybage.entity.PlanLike;

import com.cybage.entity.Plans;
import com.cybage.entity.Sports;
import com.cybage.repository.PlansRepository;
import com.cybage.repository.SportsRepository;


@Service
public class PlansServiceImpl implements PlansService {
	
	LocalDate endDate;
	//method to find planEndDate
	public LocalDate findEndDate(LocalDate startDate,
			int planDuration) {
		return startDate.plusMonths(planDuration);
	}
	
	 @Autowired 
	 PlansRepository plansRepository;
	 
	 @Autowired
	 SportsRepository sportRepository;
	 
	//get all plans/offers
	@Override
	public List<PlansDto> getAllPlans() {
		List<PlansDto> list= plansRepository.getAllPlans();
		return list;
	}
	
	//add new plan/offer
	@Override
	public Plans addPlan(Plans plan,int id) {
		//find plan end date from given plan start date and given duration in months
		endDate= findEndDate(plan.getPlanStartDate(),Integer.parseInt(plan.getPlanDuration()));
		plan.setPlanEndDate(endDate);
		
		Sports sport=sportRepository.findById(id).get();
		plan.setSport(sport);
		
		return plansRepository.save(plan);
		
	}
	
	//update particular plan/offer
	
	@Override
	public Plans updatePlan(Plans plan,int planId,int sportId) {
		//find plan end date from given plan start date and given duration in months
		endDate= findEndDate(plan.getPlanStartDate(),Integer.parseInt(plan.getPlanDuration()));
				
		plan.setPlanEndDate(endDate);
		plan.setPlanId(planId);
		plan.setSport(sportRepository.findById(sportId).get());
		return plansRepository.saveAndFlush(plan);
		
	}
	
	//find plan/offer by id
	@Override
	public Plans getPlanById(int planId){
		return plansRepository.findById(planId).get();
	}
	
	//Delete plan by id
		public void deletePlan(int id) {
			 plansRepository.deleteById(id); 
//			 return "deleted successfully";
		}

		@Override
		public List<Plans> getPlanReport() {
			System.out.println("in plan service");
				return plansRepository.findAll();
		}


}
