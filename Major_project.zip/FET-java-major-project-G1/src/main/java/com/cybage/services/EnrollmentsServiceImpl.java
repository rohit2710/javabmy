package com.cybage.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.entity.Batches;
import com.cybage.entity.EnrollmentStatus;
import com.cybage.entity.Enrollments;
import com.cybage.entity.Sports;
import com.cybage.exception.EnrollmentServiceException;
import com.cybage.repository.BatchesRepository;
import com.cybage.repository.EnrollmentRepository;
import com.cybage.repository.PlansRepository;
import com.cybage.repository.SportsRepository;
import com.cybage.repository.UsersRepository;

@Service
public class EnrollmentsServiceImpl implements EnrollmentsService {

	@Autowired
	EnrollmentRepository enrollmentsRepository;
	@Autowired
	UsersRepository usersRepository;
	@Autowired
	SportsRepository sportsRepository;
	@Autowired
	PlansRepository plansRepository;
	@Autowired
	BatchesRepository batchesRepository;
	

	//Getting enrollment details
	@Override
	public List<Enrollments> getUserEnrollments(int userId) throws EnrollmentServiceException{
		List<Enrollments> enrollments = new ArrayList<>();
		for (Enrollments e : enrollmentsRepository.findAll()) {
			if (e.getUser().getUserId() == userId) { 
				enrollments.add(e);
			}
		}
		return enrollments;
	}

	//Adding enrollment details
		@Override
		public Enrollments addUserEnrollment(int userId,int sportId,int planId,double amount,LocalDate planstartDate,LocalDate planendDate){
			Enrollments enrollment = new Enrollments();
			enrollment.setAmountPaid(amount);
			enrollment.setEnrollmentStatus(EnrollmentStatus.PENDING);
			enrollment.setPlan(plansRepository.getOne(planId));
			enrollment.setUser(usersRepository.getOne(userId));
			enrollment.setSport(sportsRepository.getOne(sportId));
			enrollment.setPlanStartDate(planstartDate);
			enrollment.setPlanEndDate(planendDate);
			return enrollmentsRepository.save(enrollment);
		}

	//renew membership
	@Override
	public int renewMembership(int enrollmentId) {
		Enrollments enrollment =  enrollmentsRepository.getOne(enrollmentId);
		enrollment.setEnrollmentStatus(EnrollmentStatus.PENDING);
		enrollment.setBatch(null);
		LocalDate newPlanStartDate = enrollment.getPlanEndDate().plusDays(1);
		int planDuration = Integer.parseInt(enrollment.getPlan().getPlanDuration());
		LocalDate newPlanEndDate = newPlanStartDate.plusMonths(planDuration);
		enrollment.setPlanStartDate(newPlanStartDate);
		enrollment.setPlanEndDate(newPlanEndDate);
		enrollmentsRepository.save(enrollment);
		return 1;
	}

	//get all pending requests with managerId
	@Override
	public List<Enrollments> getAllPendingEnrollments(int managerId) {
		
		List<Enrollments> newlist= new ArrayList<Enrollments>();
		List<Sports> sports=sportsRepository.getSportsByManagerId(managerId);
		List<Integer> sportIds = sports.stream()
                .map(Sports::getSportId).collect(Collectors.toList());
		
	    List<Enrollments> enroll=
				 enrollmentsRepository.findByEnrollmentStatus(EnrollmentStatus.PENDING);
	    
		for (Integer sId : sportIds) {
			for(Enrollments e : enroll)
			{
				if(e.getSport().getSportId()==sId)
				{
					newlist.add(e);
				}
			}
		}
	  return newlist;
	}
	
	//get enrollments by enrollmentId
	@Override
	public Enrollments getEnrollmentById(int enrollmentId) {
	     System.out.println("inside enrollservice..."+enrollmentId);
	     return enrollmentsRepository.findById(enrollmentId).get();
		
	}
	

    //	reject member without reason
	@Override
	public Enrollments rejectMember(int enrollmentId) {
		System.out.println("in enrollservice"+enrollmentId);
		Enrollments enrollment =  enrollmentsRepository.getOne(enrollmentId);
		System.out.println(enrollment);
		enrollment.setEnrollmentStatus(EnrollmentStatus.REJECTED);
		enrollmentsRepository.save(enrollment);
		return enrollment;
	}

	@Override
	public Enrollments acceptMember(int enrollmentId, int batchId) {
		System.out.println("printing enId an btId in en servi");
		System.out.println(enrollmentId);
		System.out.println(batchId);
		Enrollments enrollment =  enrollmentsRepository.getOne(enrollmentId);
		enrollment.setEnrollmentStatus(EnrollmentStatus.APPROVED);
		Batches batch=batchesRepository.findById(batchId).get();
		enrollment.setBatch(batch);
		enrollmentsRepository.save(enrollment);
		return null;
	}

	
}

//reject member with reason
//public Enrollments rejectMember(int enrollmentId,String reason) {
//	Enrollments enrollment =  enrollmentsRepository.getOne(enrollmentId);
//	enrollment.setEnrollmentStatus(EnrollmentStatus.REJECTED);
//	//enrollment.setReason(reason);
//	enrollmentsRepository.save(enrollment);
//	return enrollment;
//}
