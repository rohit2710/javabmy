package com.cybage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeccanSportClubApplicationTests {

	@Test
	void contextLoads() {
	}

}
