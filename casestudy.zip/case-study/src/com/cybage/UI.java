package com.cybage;

import java.util.Scanner;

import com.cybage.dbutil.DbUtil;

public class UI {
	public static void main(String[] args) throws Exception{
		System.out.println("Welcome to HDFC bank");
		
		BankingService bs = new BankingService();
		bs.openAccount(AccountType.SAVING.toString(), "dm101", "pune", 20000);
	}
	
	
	
	
	
	
	
	
	
//	public static void withdrawl(){
//		BankingService bs = new BankingService();
//		Scanner scan = new Scanner(System.in);
//		bs.loadAccounts();
//		bs.displayAccounts();
//		System.out.println("Please enter account number: ");
//		String accNumber = scan.next();
//		System.out.println("Please enter withdrawl amount: ");
//		double amount = scan.nextDouble();
//		try{
//			double availableBalance = bs.withdrawl(accNumber, amount);
//			System.out.println("Withdrawl success: Available balance is : "+ availableBalance);	
//		}catch(AccountException ae){
//			System.out.println("HDFC: error: 103: "+ ae.getMessage());
//		}
//	}
//	public static void openAccount(){
//		BankingService bs = new BankingService();
//		try{
//			bs.openAccount(AccountType.SAVING.toString(), "dm101", "Pune", 5000);	
//		}catch(AccountException ae){
//			System.out.println("HDFC: error 102 : "+ ae.getMessage());
//		}
//	}
//	public static void getBalance(){
//		BankingService bs = new BankingService();
//		Scanner scan = new Scanner(System.in);
//		bs.loadAccounts();
//		bs.displayAccounts();
//		System.out.println("getting balance");
//		System.out.println("Please enter account number");
//		String accNumber = scan.next();
//		try{
//			double availableBalance = bs.getBalance(accNumber);
//			System.out.println("Available balance is : "+ availableBalance);	
//		}catch(AccountException ae){
//			System.out.println("HDFC: error: 101: "+ ae.getMessage());
//		}
//	}
}