package com.cybage.dao;

import com.cybage.Account;

public interface AccountDao {
	public String addAccount(Account account) throws Exception;
}
