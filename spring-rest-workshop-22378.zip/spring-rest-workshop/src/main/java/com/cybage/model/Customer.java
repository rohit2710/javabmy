package com.cybage.model;

import java.util.List;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Transient;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int custid;
	
	private String customerName;
	private String customerPassword;
	
	@Transient
	private String confirmPassword;
	
	@Column(nullable = false, unique = true)
	private String email;
	
	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name ="cust_phone",joinColumns = @JoinColumn(name="custid"))
	private Set<String> phoneList;
	
	public Customer() {
		super();
		
	}

	public Customer(int custid, String customerName, String password, String email,
			Set<String> phoneList) {
		super();
		this.custid = custid;
		this.customerName = customerName;
		this.customerPassword = password;;
		this.email = email;
		this.phoneList = phoneList;
	}

	public int getCustid() {
		return custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String password) {
		this.customerPassword = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Set<String> getPhoneList() {
		return phoneList;
	}

	public void setPhoneList(Set<String> phoneList) {
		this.phoneList = phoneList;
	}
	
	
	
	
	
}




















