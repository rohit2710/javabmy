package com.cybage.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionController {
  
  
  @ExceptionHandler(UserException.class)
  @ResponseStatus(code =HttpStatus.INTERNAL_SERVER_ERROR)
  public String handleUserException(UserException ue) {
      return "error in processing request: " + ue.getMessage(); 
  }
  @ExceptionHandler(Exception.class)
  @ResponseStatus(code =HttpStatus.SEE_OTHER)
  public String handleException(Exception ue) {
      return "error in processing request: " + ue.getMessage(); 
  }
}
















