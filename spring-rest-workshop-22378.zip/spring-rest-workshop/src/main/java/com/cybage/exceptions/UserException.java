package com.cybage.exceptions;

public class UserException extends Exception{

	public UserException() {
		super();
	}
	
	
}
