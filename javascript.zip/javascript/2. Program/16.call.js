function fun1() {
    function Animal(voice) {
        this.voice = voice
    }
    Animal.prototype.speak = function () {
        console.log(this.voice)
    }
    function Cat(name, color) {
        Animal.call(this, "cat voice"),
            this.name = name,
            this.color = color
    };
    Cat.prototype = Object.create(Animal.prototype);
    var c1 = new Cat('cat1', 'black');
    c1.speak();//speak is not a memeber of c1 so hasOwnProperty will return false
    console.log(c1.__proto__);//Cat
    console.log(c1.__proto__.__proto__);//Object
}