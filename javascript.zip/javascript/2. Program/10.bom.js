function fun1() {
    console.log('window size: ' + window.innerHeight + ' ' + window.innerWidth)
    console.log('screen info: ' + screen.availHeight + ' ' + screen.availWidth + ' ' + screen.height + ' ' + screen.pixelDepth)

    console.log('browser codename: ' + navigator.appCodeName)
    console.log('browser name: ' + navigator.appName)
    console.log('app version: ' + navigator.appVersion)

    console.log('cookie enabled: ' + navigator.cookieEnabled)
    console.log('navigator language: ' + navigator.language)
    console.log('Platform: ' + navigator.platform)

    console.log('window location info: ' + location.href + ' ' + location.hostname + ' ' + location.pathname + ' ' + location.protocol)
}

function fun2() {
    //open window
    window.open()
}
function back() {
    window.history.back();
}

function forword() {
    window.history.forward()
}