function fun1() {
    var num = 10;
    var name = 'dmjadhav'
    var per = 64.33;
    var emp = {name: "dmjadhav", address:"pune", phone: "90110"};       //object
    var isWorking = true;
    var skills = ['java', 'javascript', 'angular']
    var mobile
    var email = ""          //empty value
    console.log('number: '+ num)
    console.log('name: '+ name)
    console.log('percentage: '+ per)
    console.log('emp object: ')
    console.log(emp) 
    console.log('currently working or not? '+ isWorking)
    num = 'Cybage, pune'
    console.log('organization name' + num);
    console.log('skills: '+ skills)
    console.log('mobile number is : '+ mobile)
    console.log('email: '+ email)
    //You can use the JavaScript typeof operator to find the type of a JavaScript variable.
    console.log('type of emp is : ')
    console.log(typeof emp)

    //object can be make empty using null
    emp = null;
    console.log('updated object')
    console.log(emp)

    //possible using undefined also
    emp = undefined
    console.log('updated object')
    console.log(emp)


}