const { of } = require('rxjs')
const { Subject } = require('rxjs/Subject');

const s1 = new Subject();

s1.subscribe({
    next: v => console.log("observerA: " + v)
});
s1.subscribe({
    next: v => console.log("observerB: " + v)
});

s1.next(1);
s1.next(2);