const { Observable, from } = require('rxjs')
const { filter, map, last } = require('rxjs/operators');

const sourceObservable = from([1, 2, 3, 4, 5, 6, 7, 8, 9, 5]);

sourceObservable
.pipe(filter((x) => x % 2), map((x) => x * 2))
.subscribe((x) => console.log('Next: ' + x));