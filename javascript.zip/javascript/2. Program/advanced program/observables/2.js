const { Observable, from } = require('rxjs')
const { filter } = require('rxjs/operators');

const data = from([1, 2, 3, 4, 5, 6, 7, 8, 9]);

data
.pipe(filter((x) => x % 2))
.subscribe((x) => console.log('Next: ' + x));