function fun1() {
    console.log('button clicked...');
}
function fun2() {
    document.getElementById("heading").innerHTML = "updated contents in h1 tag..."
}
function fun3() {
    // alert('just a alert :)');
    window.alert('just a alert :)')
    console.log('button clicked...')    
}
function fun4(){
    //it deletes all contents
    document.write('it is using document.write... which erase all contents')
    document.getElementById
    document.getElementsByClassName
    document.getElementsByTagNameNS
    document.querySelector
}