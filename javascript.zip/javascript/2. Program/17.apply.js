var person = {
    firstName:"dm",
    lastName: "jadhav",
    fullName: function() {
        return this.firstName + " " + this.lastName;
    }
}
var myObject = {
    fn:"dadaram",
    ln: "jadhav",
}
person.fullName.apply(myObject);  // Will return "dadaram jadhav"

/*
The Difference Between call() and apply()
call() takes any function arguments separately.
apply() takes any function arguments as an array.
The apply() method is very handy if you want to use an array instead of an argument list.
*/