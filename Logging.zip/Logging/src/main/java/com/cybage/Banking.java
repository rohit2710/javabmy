package com.cybage;

import java.util.List;

//banking rules will be defined by rbi and all bank need to adhere to rbi rules
public interface Banking {
	public static float roiSaving = 6.5F;
	public static float roiCurrent = 7.5F;
	public String openAccount(
			String accType, 
			String name, 
			String address, 
			double balance
			) throws AccountException, Exception;
	public double getBalance(String accNumber) throws AccountException, Exception;
	public double withdrawl(String accNumber, double amount) throws Exception;
	public List<AccountInfo> getAllAccounts() throws Exception;
	public double getROI(String custId) throws Exception;
}
