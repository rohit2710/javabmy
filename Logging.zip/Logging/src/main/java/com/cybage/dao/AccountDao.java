package com.cybage.dao;

import java.util.List;

import com.cybage.Account;
import com.cybage.AccountException;
import com.cybage.AccountInfo;

public interface AccountDao {
	public String addAccount(Account account) throws Exception;
	public double getBalance(String accNumber) throws AccountException, Exception;
	public double withdraw(String accNumber,double amountWith) throws Exception;
	public List<AccountInfo> getAllAccount() throws Exception;
	public Account getCustomerBalance(String custID) throws Exception;
}
