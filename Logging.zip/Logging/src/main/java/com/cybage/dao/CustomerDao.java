package com.cybage.dao;

import com.cybage.Customer;

public interface CustomerDao {
	public  String addCustomer(Customer cust) throws Exception;
}
