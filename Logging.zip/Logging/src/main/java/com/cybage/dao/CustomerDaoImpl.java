package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cybage.Customer;
import com.cybage.dbutil.DbUtil;

public class CustomerDaoImpl implements CustomerDao {
	@Override
	public String addCustomer(Customer cust) throws Exception {
		String sql = "insert into customer values(?, ?, ?)";
		Connection con = DbUtil.getConnection();			//new object
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, cust.getCustId());
		ps.setString(2, cust.getCustName());
		ps.setString(3, cust.getCustAddress());
		ps.executeUpdate();
			ps.close(); 
			con.close();  
			return cust.getCustId();
	}
}
