package com.cybage;

import java.util.List;
import java.util.Scanner;

import com.cybage.dbutil.DbUtil;

public class UI {
	public static void main(String[] args) throws Exception{
		Scanner sc=new Scanner(System.in);
		int choice;
		do {
			System.out.println("***********************Welcome to ICICI bank*************************");
			System.out.println("1)create Account \n2)See Balance \n3)Withdraw \n4)All Account \n5)Calculate ROI \n6)Exit");
			System.out.println("Enter Your Choice");
			choice=sc.nextInt();
			BankingService bs = new BankingService();
			switch(choice)
			{
			case 1:
				System.out.println("1.Saving \n2.Current");
				int accTy=sc.nextInt();
				System.out.println("Enter Your Name");
				String name=sc.next();
				System.out.println("Enter Address");
				String address=sc.next();
				System.out.println("Enter Amount to Deposit");
				double amout=sc.nextDouble();
				
				if(accTy==1)
				{
					bs.openAccount(AccountType.SAVING.toString(), name, address, amout);
					System.out.println("Acount Created successfully");
				}
				else
				{
					bs.openAccount(AccountType.CURRENT.toString(), name, address, amout);
					System.out.println("Acount Created successfully");
				}
				break;
			case 2:
			{
				System.out.println("Enter Your Account number");
				String accNo=sc.next();
				System.out.println("avaliable balance: " + bs.getBalance(accNo));		
				break;
			}
			case 3:
			{
				System.out.println("Enter Your Account number");
				String accNo=sc.next();
				System.out.println("Enter Withdraw Amount");
				double amount=sc.nextDouble();
				System.out.println("Balance After Withdraw:"+bs.withdrawl(accNo, amount));
				break;
			}
			case 4:
				System.out.println("******************ALL ACCOUNT****************************");
				List<AccountInfo> list=bs.getAllAccounts();
				list
					.forEach((acc)->System.out.println(acc));
				break;
			case 5:
			System.out.println("Enter Customer ID");
			String custId=sc.next();
			System.out.println(bs.getROI(custId));
				break;
			case 6:
				
				break;
			default:
				System.out.println("Wrong choice");
			}
			
		}while(choice !=6);
		System.out.println("Exiting.....");

		
		//value will come from html page from user
		

		//getting balance
		//System.out.println("avaliable balance: " + bs.getBalance("H92330"));			
	}
}