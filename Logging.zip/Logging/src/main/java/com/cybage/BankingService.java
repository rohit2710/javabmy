package com.cybage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import com.cybage.dao.AccountDao;
import com.cybage.dao.AccountDaoImpl;
import com.cybage.dao.CustomerDao;
import com.cybage.dao.CustomerDaoImpl;
import com.cybage.dbutil.DbUtil;

//this class is specific certain project
public class BankingService implements Banking{

	CustomerService cs = new CustomerService();
	AccountDao dao = new AccountDaoImpl();
	CustomerDao custDao=new CustomerDaoImpl();
	
	public String generateAccNumber(){
		return "H"+ Math.round(Math.random()*99999);
	}
	@Override
	public String openAccount(String accType,
			String name, 
			String address, 
			double balance) throws AccountException, Exception
	{		
		if(balance < 10000){
			throw new AccountException("Cannot create account as amount is less than 10000");
		}
		 

		//1. create customer
		Customer c1 = cs.addCustomer(name, address);
		custDao.addCustomer(c1);
		//store customer in database
		//logically this code should go to customerdao
			
		
		
		//need to create account and store in database
		Account account = null;
		switch (accType) {
		case "SAVING":	
			account = new SavingAccount(generateAccNumber(), accType, c1.getCustId(), balance);
			break;
		case "CURRENT":
			account = new CurrentAccount(generateAccNumber(), accType, c1.getCustId(), balance);
			break;
		default: 
			account = null;
		}
		
		return dao.addAccount(account);
	}
	@Override
	public double getBalance(String accNumber) throws AccountException, Exception{
		return dao.getBalance(accNumber);		
	}
	
	@Override
	public double withdrawl(String accNumber, double amount) throws Exception {
		
		  double availableBalance; 
		  double tempBalance = 0; 
		
		  //get available balance
		  availableBalance=getBalance(accNumber);
		  //showing current balance
		  System.out.println("Current Balance "+availableBalance);
			if(availableBalance >amount)
			{
				tempBalance=availableBalance-amount;
			}
			else
			{
				throw new Exception("Unsufficient Balance");
			}
			if(tempBalance < 10000)
			{
				throw new Exception("Balance goes below 10000");
			}
			else
			{
				double currentAmout=dao.withdraw(accNumber, tempBalance);
				return currentAmout;
			}
		 
//		for(Account account: accounts){
//			if(account.getAccNumber().equals(accNumber)){
//				availableBalance = account.getBalance();
//				tempBalance = availableBalance - amount;
//				if(tempBalance < 10000){
//					throw new AccountException("Cannot withdrawl as effective balance goes below 10000");
//				}else{
//					account.setBalance(tempBalance);
//				}
//				found = true;
//				break;
//			}
//		}
		/*
		 * if(found) return tempBalance; else { throw new
		 * AccountException("Account does not exists"); }
		 */
		
	}
	@Override
	public List<AccountInfo> getAllAccounts() throws Exception {
		List<AccountInfo> list=dao.getAllAccount();
		return list;
	}
	@Override
	public double getROI(String custId) throws Exception{
		Account acc=dao.getCustomerBalance(custId);
		if(acc instanceof CurrentAccount)
		{
			System.out.println("Current Account");
			return roiCurrent*acc.getBalance()*1/100;
		}
		else
		{
			System.out.println("Saving Account");
			return roiSaving*acc.getBalance()*1/100;
		}
		
	}
}