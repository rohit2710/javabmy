package com.cybage;

public class CurrentAccount extends Account{

	//can add more properties
	public CurrentAccount() {
		super();
	}

	public CurrentAccount(String accNumber, String accType, String custId, double balance) {
		super(accNumber, accType, custId, balance);
	}	
}
