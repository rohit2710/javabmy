package com.cybage;

public class AccountInfo {
	private String accNumber;
	private String accType;
	private String custId;
	private String custName;
	private double balance;
	public AccountInfo(String accNumber, String accType, String custId, String custName, double balance) {
		super();
		this.accNumber = accNumber;
		this.accType = accType;
		this.custId = custId;
		this.custName = custName;
		this.balance = balance;
	}
	public AccountInfo() {
		super();
	}
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "AccountInfo [accNumber=" + accNumber + ", accType=" + accType + ", custId=" + custId + ", custName="
				+ custName + ", balance=" + balance + "]";
	}
	
	

}
